@echo off
setlocal
cd /d "%~dp0"
dotnet run --project windows\Checks\Tracker.Checks.csproj
if errorlevel 1 exit /b 1
dotnet publish windows\App\Tracker.App.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -o release\win-x64
exit /b %errorlevel%
