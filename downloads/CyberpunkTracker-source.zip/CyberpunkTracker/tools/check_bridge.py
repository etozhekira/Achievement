"""Run CET bridge under real Lua with mocked CET callbacks, in a temporary folder."""
import ctypes, json, os, pathlib, shutil, tempfile
root=pathlib.Path(__file__).resolve().parents[1]
lib=ctypes.CDLL('liblua5.4.so.0')
lib.luaL_newstate.restype=ctypes.c_void_p
lib.luaL_openlibs.argtypes=[ctypes.c_void_p]
lib.luaL_loadstring.argtypes=[ctypes.c_void_p,ctypes.c_char_p];lib.luaL_loadstring.restype=ctypes.c_int
lib.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong,ctypes.c_void_p];lib.lua_pcallk.restype=ctypes.c_int
lib.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];lib.lua_tolstring.restype=ctypes.c_char_p
lib.lua_close.argtypes=[ctypes.c_void_p]
code=r'''
local callbacks={};local observers={}
json={encode=function(t)
 local rows={}
 for k,v in pairs(t) do
   local value
   if type(v)=='string' then value=string.format('%q',v)
   else value=tostring(v) end
   rows[#rows+1]=string.format('%q',k)..':'..value
 end
 return '{'..table.concat(rows,',')..'}'
end}
function registerForEvent(event, fn) callbacks[event]=fn end
function ObserveAfter(class, method, fn)
 assert(method=='UnlockAchievement','only unlock is observed')
 observers[#observers+1]=fn
end
function EnumInt(v) error('test fallback: unsupported') end
dofile('init.lua')
callbacks.onInit()
assert(#observers==2)
observers[1]({},'gamedataAchievement.TheFool')
observers[1]({},40) -- same enum, duplicate must be harmless to receiver
observers[1]({},999) -- unknown is rejected
observers[1]({},'gamedataAchievement.TheLovers')
observers[1]({},setmetatable({value='TheWorld'},{__tostring=function()return 'gamedataAchievement : TheWorld (48)'end}))
callbacks.onUpdate(6)
callbacks.onShutdown()
'''
with tempfile.TemporaryDirectory() as d:
 for name in ['init.lua','ids.lua']:shutil.copy(root/'CET-мост'/'local_achievement_bridge'/name,d)
 old=os.getcwd();os.chdir(d)
 state=lib.luaL_newstate();lib.luaL_openlibs(state)
 try:
  rc=lib.luaL_loadstring(state,code.encode()) or lib.lua_pcallk(state,0,0,0,0,None)
  if rc:raise RuntimeError(lib.lua_tolstring(state,-1,None).decode())
  rows=[json.loads(l) for l in pathlib.Path('unlocks.jsonl').read_text().splitlines()]
  assert [r['id'] for r in rows]==['TheFool','TheFool','TheLovers','TheWorld'],rows
  assert all(r['event']=='achievement_unlocked' for r in rows)
  status=json.loads(pathlib.Path('bridge-status.json').read_text())
  assert status['events']==4 and status['observed'] is True
  print('PASS: real Lua parses bridge; enum name and numeric IDs work; unknown ID rejected; JSONL/status valid.')
  print('NOTE: CET engine hooks mocked; compatibility with actual game is not established.')
 finally:lib.lua_close(state);os.chdir(old)
