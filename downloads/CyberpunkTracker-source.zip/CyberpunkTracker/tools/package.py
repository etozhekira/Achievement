"""Package the built executable and read-only bridge, never user saves/state."""
from pathlib import Path
import hashlib, json, zipfile
root=Path(__file__).resolve().parents[1]
exe=root/'release'/'win-x64'/'CyberpunkTracker.exe'
if not exe.exists():raise SystemExit('Build EXE first')
readme='''CYBERPUNK TRACKER — Windows 10/11 x64

1. Распакуйте этот архив в отдельную папку и запустите CyberpunkTracker.exe.
   Python, Codex и отдельная установка .NET не нужны.
2. Стартовое время по вашему сейву: 11 ч 10 мин 15,822 с. Две отметки «Шут» и
   «Влюблённые» уже имеют источник «сейв». «Стартовое время» меняет базу.
3. Перед игрой оставьте программу открытой или нажмите «В трей».
   Таймер автоматически отслеживает Cyberpunk2077.exe и сохраняет сессии.
4. Нажмите «Папка сейвов», если она не определилась автоматически.

ДЛЯ АВТОМАТИЧЕСКИХ УВЕДОМЛЕНИЙ CET

Закройте игру. Скопируйте local_achievement_bridge из папки CET-мост в:
<папка игры>\\bin\\x64\\plugins\\cyber_engine_tweaks\\mods

В программе нажмите «Папка игры» и выберите корень установки Cyberpunk 2077.
Запустите игру с работающим CET. Сам трекер ничего не записывает в игру/сейвы.
Установленный вами мост пишет только собственный журнал unlocks.jsonl.

Прямоугольные уведомления показываются справа сверху, без перехвата управления.
Режим игры: оконный или без рамки. В эксклюзивном полноэкранном режиме обычное
окно Windows может не отображаться. Кнопка «Проверить уведомление» показывает
пример и не изменяет достижения. В строке статуса указано состояние моста.

Перехват CET в вашей конкретной сборке игры пока не проверен. Его регистрация
не выдаётся за доказательство работы: мост сообщает отдельно, получил ли он
реальное событие. Не вызывайте UnlockAchievement в консоли ради проверки.

57 достижений, русские названия/условия, собственные картинки (не значки Steam).
Сейв проверяется консервативно: q001, q005, streetCred=50. Бинарный sav.dat пока
не разбирается; остальные ачивки требуют события журнала или ручной отметки.
Стандартный текстовый CET-лог не обязан содержать историю разблокировок.

Данные программы: %LOCALAPPDATA%\\CyberpunkLocalTracker\\state-v2.json
Предыдущее состояние: state-v2.json.bak. Повторный запуск не добавляет базу снова.
Сессии считают работу процесса, включая меню. Пока трекер закрыт, учёта нет.

Встроенной сетевой связи, регистрации аккаунта и синхронизации Steam нет.
Подробные сведения: README.md и docs/ANALYSIS.md в архиве исходников.
'''
(root/'release'/'НАЧНИТЕ ЗДЕСЬ.txt').write_text(readme,encoding='utf-8-sig')
sha=hashlib.sha256(exe.read_bytes()).hexdigest()
(root/'release'/'SHA256.txt').write_text(f'{sha}  CyberpunkTracker.exe\n')
with zipfile.ZipFile(root.parent/'CyberpunkTracker-Windows-x64.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(exe,'CyberpunkTracker.exe')
 z.write(root/'release'/'НАЧНИТЕ ЗДЕСЬ.txt','НАЧНИТЕ ЗДЕСЬ.txt')
 z.write(root/'release'/'SHA256.txt','SHA256.txt')
 for p in (root/'CET-мост').rglob('*.lua'):z.write(p,p.relative_to(root))
 for p in (root/'release'/'Лицензии').glob('*.txt'):z.write(p,Path('Лицензии')/p.name)
with zipfile.ZipFile(root.parent/'CyberpunkTracker-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in root.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if any(part in {'.git','bin','obj','__pycache__','release','.venv'} for part in rel.parts):continue
  if p.suffix in {'.pyc','.zip','.pdb'}:continue
  z.write(p,Path('CyberpunkTracker')/rel)
print('EXE SHA256:',sha)
for p in [root.parent/'CyberpunkTracker-Windows-x64.zip',root.parent/'CyberpunkTracker-source.zip']:
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert not any(n.endswith(('sav.dat','state-v2.json')) for n in z.namelist())
 print(p.name,p.stat().st_size,'bytes; ZIP verified')
