using CyberpunkTracker;
using System.Text.Json;
using System.Security.Cryptography;
var temp=Path.Combine(Path.GetTempPath(),"TrackerChecks-"+Guid.NewGuid());Directory.CreateDirectory(temp);
int count=0;
void Check(bool condition,string message){if(!condition)throw new Exception("FAIL: "+message);Console.WriteLine("PASS: "+message);count++;}
var cat=new List<Achievement>{new(){Id="TheFool",Label="Шут"},new(){Id="TheLovers",Label="Влюблённые"},new(){Id="TheWorld",Label="Мир"},new(){Id="YouKnowWhoIAm",Label="Легенда"}};
try {
 var p=Path.Combine(temp,"state.json");
 using(var e=new Engine(p,cat)){
  e.Tick(true,0);e.Tick(true,2);e.Tick(false,3);Check(Math.Abs(e.TotalSeconds-40218.822473)<0.0001,"timer counts session, baseline once");e.Save();
 }
 using(var e=new Engine(p,cat)){
  e.Tick(true,1000);e.Tick(false,1002);Check(e.Data.Sessions.Count==2,"session history survives restart");Check(Math.Abs(e.TotalSeconds-40220.822473)<0.0001,"downtime not counted");
  e.Tick(true,2000);e.Tick(true,5600);Check(e.Data.Sessions.Last().Seconds==5,"suspend gap capped");e.Tick(false,5600);
  var metadata=Path.Combine(temp,"metadata.9.json");File.WriteAllText(metadata,"""{"RootType":"saveMetadataContainer","Data":{"metadata":{"playTime":40215.822473,"finishedQuests":"q001 q005 sq012 "}}}""");
  var hash=SHA256.HashData(File.ReadAllBytes(metadata));double before=e.TotalSeconds;
  var result=e.Import(metadata);Check(result.Added==2,"q001 and q005 confirm exactly two achievements");
  e.Import(metadata);Check(e.TotalSeconds==before,"reimport does not replace baseline or accumulated sessions");
  Check(hash.SequenceEqual(SHA256.HashData(File.ReadAllBytes(metadata))),"imported save remains byte-for-byte unchanged");
  Check(!e.Data.Achievements.ContainsKey("TheWorld"),"other achievements stay unconfirmed");
  var json=Path.Combine(temp,"achievements.json");File.WriteAllText(json,"""{"achievements":[{"id":"TheWorld","progress":100},{"id":"Unknown","unlocked":true}]}""");
  Check(e.Import(json).Added==0,"progress and unknown IDs cannot unlock achievements");
  var log=Path.Combine(temp,"events.jsonl");File.WriteAllText(log,"{\"event\":\"achievement_unlocked\",\"id\":\"TheWorld\"");
  int notified=0;e.Unlocked+=(_,_)=>notified++;
  Check(e.ReadLog(log)==0,"partial log entry is deferred");
  File.AppendAllText(log,"}\n");Check(e.ReadLog(log)==1&&notified==1,"completed live event confirms and notifies once");
  e.ReadLog(log);File.AppendAllText(log,"{\"event\":\"achievement_unlocked\",\"id\":\"TheWorld\"}\n");e.ReadLog(log);Check(notified==1,"duplicate events never repeat toast");
  e.Confirm("TheWorld","вручную","user");e.RemoveManual("TheWorld");Check(e.Data.Achievements["TheWorld"].Any(r=>r.Source=="журнал"),"removing manual evidence preserves log evidence");
  var legend=Path.Combine(temp,"legend.json");File.WriteAllText(legend,"""{"RootType":"saveMetadataContainer","Data":{"metadata":{"streetCred":50}}}""");
  Check(e.Import(legend).Added==1&&e.Data.Achievements["YouKnowWhoIAm"].Any(r=>r.Source=="сейв"),"streetCred=50 confirms Legend from save");
  var api=Path.Combine(temp,"api.json");File.WriteAllText(api,"{\"classes\":[],\"enums\":[]}");Check(e.Import(api).Added==0,"API metadata cannot confirm progress");
  var map=Path.Combine(temp,"earned.json");File.WriteAllText(map,"{\"TheFool\":{\"earned\":true},\"TheLovers\":{\"earned\":false}}");e.Import(map);Check(e.Data.Achievements["TheFool"].Any(r=>r.Detail==map),"earned=true JSON map import");
 }
 var corrupt=Path.Combine(temp,"corrupt.json");File.WriteAllText(corrupt,"broken");try{new Engine(corrupt,cat);throw new Exception("corrupt accepted");}catch(JsonException){Check(File.ReadAllText(corrupt)=="broken","corrupt state never silently overwritten");}
 if(args.Length>0){using var actual=new Engine(Path.Combine(temp,"actual.json"),cat);var bytes=SHA256.HashData(File.ReadAllBytes(args[0]));var r=actual.Import(args[0]);Check(r.Added==2,"actual attached save imports two quest confirmations");Check(bytes.SequenceEqual(SHA256.HashData(File.ReadAllBytes(args[0]))),"actual attachment unchanged");}
 Console.WriteLine($"{count} checks passed.");
}finally{Directory.Delete(temp,true);}
