-- Read-only observer of achievement requests. Does not unlock achievements,
-- alter quest facts or modify saves. Only writes files in this mod's folder.
local ids = dofile('ids.lua')
local missions = dofile('missions.lua')
local valid = {}
for _, name in pairs(ids) do valid[name] = true end
local registered = false
local observed = false
local events = 0
local elapsed = 0
local state = 'ожидание регистрации'
local lastError = ''

local function status()
  local f = io.open('bridge-status.json', 'w')
  if not f then return end
  -- CET bundles the json module; data is local status, never executable content.
  f:write(json.encode({ version = 1, state = state, events = events,
    observed = observed, lastError = lastError, updated = os.time() }))
  f:close()
end

local function identify(value)
  if value == nil then return nil end
  local raw = tostring(value)
  if valid[raw] then return raw end
  local suffix = raw:match('%.([%w_]+)$') or raw:match('::([%w_]+)$')
  if suffix and valid[suffix] then return suffix end
  local n = tonumber(raw)
  if n and ids[n] then return ids[n] end
  -- CET Enum.value is its symbolic name (confirmed in CET Scripting.cpp).
  local ok, v = pcall(function() return value.value end)
  if ok and type(v) == 'string' and valid[v] then return v end
  if ok and type(v) == 'number' then return ids[v] end
  if type(EnumInt) == 'function' then
    local success, int = pcall(EnumInt, value)
    if success then return ids[tonumber(int)] end
  end
  return nil
end

local function unlocked(self, achievement)
  -- Do not guess from progress, thresholds, game time, or arbitrary numbers.
  local name = identify(achievement)
  if not name then
    lastError = 'UnlockAchievement: неизвестный аргумент ' .. tostring(achievement)
    state = 'событие получено, ID не распознан'; status(); return
  end
  local f = io.open('unlocks.jsonl', 'a')
  if not f then state = 'не удалось открыть журнал'; status(); return end
  f:write(json.encode({event='achievement_unlocked', id=name,
    source='CET UnlockAchievement', timestamp=os.time()}), '\n')
  f:flush(); f:close()
  events = events + 1; observed = true
  state = 'события выдачи получены'; lastError = ''; status()
end

registerForEvent('onInit', function()
  local observer = ObserveAfter or Observe
  if type(observer) ~= 'function' then
    state='CET: Observe недоступен';status();return
  end
  -- Runtime script alias is AchievementSystem; native RTTI name is also tried.
  for _, class in ipairs({'AchievementSystem', 'gameAchievementSystem'}) do
    local ok, err = pcall(observer, class, 'UnlockAchievement', unlocked)
    if ok then registered = true
    else lastError = tostring(err) end
  end
  state = registered and 'запрос наблюдения отправлен, ждёт реального события' or 'регистрация наблюдателя не удалась'
  -- Registration does not prove the callback works in this particular game build.
  status()
end)
registerForEvent('onUpdate', function(dt)
  elapsed = elapsed + dt
  if elapsed >= 5 then elapsed=0;status();missions.poll() end
end)
registerForEvent('onShutdown', function()
  state = 'игра закрыта';status()
end)
