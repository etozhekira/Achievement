-- This module only reads quest facts and tarot entries. No SetFact or journal writes.
local lastRequest=nil
local facts={'mq033_current_count','mq033_grafitti_counter','mq033_done',
 'mq033_ep1_done','sq025_active','sq025_scans_done','sq025_done','sq025_delamain_done',
 'sq025_angry_done','sq025_mean_done','sq025_sad_done','sq025_suicidal_done',
 'sq025_deep_done','sq025_manic_done','sq025_scared_done','ow_psychos_done',
 'ow_psychos_killed','ow_psychos_reward_collected'}
local function process()
 local f=io.open('mission-request.json','r');if not f then return end
 local raw=f:read(4097);f:close();if #raw>4096 then return end
 local ok,r=pcall(json.decode,raw);if not ok or type(r)~='table' then return end
 if r.version~=1 or r.action~='inspect_missions' or type(r.id)~='string' or #r.id>64 then return end
 if r.id==lastRequest then return end
 if type(r.expires)~='number' or r.expires<os.time() or r.expires>os.time()+120 then return end
 -- Only process while a player exists; never change facts or run arbitrary strings.
 if not Game or not Game.GetPlayer() then return end
 lastRequest=r.id
 local report={version=1,requestId=r.id,readOnly=true,updated=os.time(),facts={},tarots={}}
 local success,err=pcall(function()
  local qs=Game.GetQuestsSystem()
  for _,name in ipairs(facts) do report.facts[name]=tonumber(qs:GetFactStr(name)) end
  local jm=Game.GetJournalManager()
  local entries=jm:GetTarots()
  for _,entry in ipairs(entries) do
   report.tarots[#report.tarots+1]={id=tostring(entry:GetId()),index=tonumber(entry:GetIndex()),
    minor=entry:GetIsMinorArcana(),state=tostring(jm:GetEntryState(entry))}
  end
 end)
 if not success then report.error=tostring(err) end
 local out=io.open('missions-report.json','w');if out then out:write(json.encode(report));out:close() end
end
return {poll=process}
