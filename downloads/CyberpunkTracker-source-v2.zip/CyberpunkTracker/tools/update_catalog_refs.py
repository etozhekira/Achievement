import json
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'catalog.json';rows=json.loads(p.read_text())
names={
'Denied':'Ответный удар','Roleplayer':'Тени прошлого','Cyberjunkie':'Автозамена','MasterRunner':'Тут всё заскриптовано','HandyMan':'Киберконструирование','TwoHeadsOneBullet':'Две головы, одна пуля','MaxPain':'Тихо едешь, быстро сдохнешь','IAmMaxTac':'Я здесь закон','VForVendetta':'V значит вендетта','MustBeTheRats':'Крысы, что ли?','EasyComeEasyGo':'Берегись автомобиля','TradeUnion':'Городские джунгли','DirtyWork':'Грязная работа','LikeFatherLikeSon':'Голос улиц','Bladerunner':'Центр мира','GetMeThereScottie':'Перелётная птица','ThisIsPacifica':'Добро пожаловать в Пасифику!','Gearhead':'Полный фарш','DogtownLaw':'Внимание, розыск!','RelicMaster':'Сила биочипа','NoMansLand':'Бесплодные земли','HydraIsDead':'Страшный суд','NotTheMobile':'Граната пошла','QueenOfTheHighway':'Развилки и перекрёстки','BushidoAndChill':'Кино, вино и «Бусидо»','UnderPressure':'Джуди в большом городе','FollowingTheRiver':'Служить и защищать','BornToBeWild':'За всё плохое!','Kingmaker':'Кто тут у нас крайний?'}
desc={
'Denied':'Убить или оглушить врага, который кинул в вас гранату.',
'Roleplayer':'Выбрать 10 вариантов ответа, связанных с прошлым Ви.',
'Cyberjunkie':'Установить не менее одного импланта в каждую систему и часть тела.',
'MasterRunner':'Выполнить взлом протокола, отправив не менее 3 демонов.',
'HandyMan':'Изготовить 3 легендарных предмета.',
'TwoHeadsOneBullet':'Убить или оглушить 2 врагов одним выстрелом из снайперской винтовки.',
'MaxPain':'Убить или оглушить 50 врагов в замедленном времени.',
'IAmMaxTac':'Выполнить все задания из серии «Приступ киберпсихоза».',
'MustBeTheRats':'Отправить скрипт «Отвлечение врагов» 30 раз, не привлекая к себе внимания.',
'EasyComeEasyGo':'Угнать медицинскую машину «Арасаки» для Эль Капитана или доставить ему 10 транспортных средств.',
'NotTheMobile':'Убить или оглушить 3 врагов одним скриптом «Взрыв гранаты».',
'TheTower':'Выполнить задание «Наёмника никто не ждёт».',
'KingOfTheSwords':'Вернуть Сойку домой.',
'KingOfTheWands':'Отправить Сойку к звёздам.',
'KingOfThePentacles':'Отказаться выполнить просьбу Сойки.',
'KingOfTheCups':'Выполнить просьбу Сойки.'}
for r in rows:
 r['label']=names.get(r['id'],r['label']);r['description']=desc.get(r['id'],r['description'])
 if r['id'] in {'GunKata','Gunslinger','TwoHeadsOneBullet','ThatIsSoHardForTheKnees','NotTheMobile','MaxPain','VForVendetta','TrueSoldier','TrueWarrior','Denied','MustBeTheRats'}:kind='Боевые условия: событие выдачи CET; прошлые убийства по метаданным не восстанавливаются.'
 elif r['id'] in {'TheFool','TheLovers','TheWheelOfFortune','TheHermit'}:kind='Завершённые задания / квестовые флаги сейва и событие выдачи CET.'
 elif r['id']=='YouKnowWhoIAm':kind='streetCred=50 в метаданных сейва и событие выдачи CET.'
 elif r['id']=='Fortuneteller':kind='Счётчик mq033_grafitti_counter из sav.dat; открытие подтверждается событием CET, счётчик сам отметку не выдаёт.'
 else:kind='Событие выдачи CET, импорт реального журнала или ручная отметка; правила по сейву пока не подтверждены.'
 r['tracking']=kind
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2))
