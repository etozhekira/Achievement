"""Original small neon illustrations; no downloaded Steam images."""
import math

def emblem(d,key,c):
    def line(p,w=4):d.line(p,fill=c,width=w,joint='curve')
    def ellipse(box,w=3):d.ellipse(box,outline=c,width=w)
    def polygon(p):d.polygon(p,fill=c)
    def star(cx,cy,r,inner=0.45,n=5):
        return [(cx+(r if i%2==0 else r*inner)*math.cos(i*math.pi/n-math.pi/2),cy+(r if i%2==0 else r*inner)*math.sin(i*math.pi/n-math.pi/2)) for i in range(2*n)]
    if key=='TheSun':
        ellipse((48,40,80,72),4)
        for i in range(12):
            a=i*math.pi/6;line([(64+24*math.cos(a),56+24*math.sin(a)),(64+33*math.cos(a),56+33*math.sin(a))],3)
    elif key=='TheStar':polygon(star(64,57,33))
    elif key in ['TheWorld','GetMeThereScottie']:
        ellipse((31,24,97,90));ellipse((49,24,79,90));line([(33,57),(95,57)],2);line([(40,39),(88,39)],2);line([(40,75),(88,75)],2)
    elif key=='TheWheelOfFortune':
        ellipse((32,25,96,89),4);ellipse((56,49,72,65))
        for i in range(8):
            a=i*math.pi/4;line([(64+10*math.cos(a),57+10*math.sin(a)),(64+31*math.cos(a),57+31*math.sin(a))],3)
    elif key in ['TheLovers','VForVendetta']:
        d.ellipse((33,35,65,67),fill=c);d.ellipse((63,35,95,67),fill=c);polygon([(33,52),(95,52),(64,89)])
        if key=='VForVendetta':line([(29,65),(48,65),(54,50),(62,78),(71,59),(98,59)],3)
    elif key in ['TheTower','Bladerunner','YipMan','NoMansLand','LittleTokyo','LikeFatherLikeSon','TradeUnion','ThisIsPacifica']:
        for i,h in enumerate([30,48,37,57,23]):
            x=32+i*13;h=h-((sum(map(ord,key))+i)%10);d.rectangle((x,87-h,x+10,87),outline=c,width=2)
            for y in range(88-h,82,9):d.rectangle((x+3,y,x+6,y+3),fill=c)
        line([(27,89),(101,89)],3)
    elif key in ['TheDevil','IAmMaxTac','DogtownLaw']:
        ellipse((40,34,88,78),4);polygon([(41,45),(34,24),(55,36)]);polygon([(87,45),(94,24),(73,36)]);d.rectangle((50,70,78,85),outline=c,width=3)
        d.ellipse((49,48,60,59),fill=c);d.ellipse((68,48,79,59),fill=c)
        for x in [57,65,73]:line([(x,75),(x,84)],2)
    elif key in ['KingOfTheCups','KingOfThePentacles','KingOfTheWands','KingOfTheSwords','Kingmaker','YouKnowWhoIAm']:
        polygon([(34,43),(48,56),(64,29),(80,56),(94,43),(86,82),(42,82)]);line([(43,87),(85,87)],3)
        for x in [35,64,93]:ellipse((x-3,27 if x==64 else 37,x+3,33 if x==64 else 43),2)
    elif key in ['GunKata','Gunslinger','TrueSoldier']:
        polygon([(31,40),(97,40),(97,53),(66,53),(62,62),(54,62),(51,83),(36,79),(43,53),(31,53)])
        line([(64,53),(77,53),(77,64),(61,64)],2)
    elif key in ['TrueWarrior','BushidoAndChill']:
        polygon([(42,79),(81,29),(91,24),(91,36),(51,85)]);line([(34,71),(61,91)],5);line([(36,91),(46,80)],7)
    elif key in ['Cyberjunkie','MasterRunner','RelicMaster']:
        d.rounded_rectangle((42,36,86,80),radius=5,outline=c,width=4);d.rectangle((51,45,77,71),outline=c,width=2)
        for v in range(48,80,12):
            line([(v,27),(v,36)],3);line([(v,80),(v,89)],3);line([(33,v),(42,v)],3);line([(86,v),(95,v)],3)
    elif key in ['NotTheMobile','Denied','HydraIsDead']:
        ellipse((44,44,84,89),4);d.rectangle((51,34,76,46),outline=c,width=3);line([(62,34),(73,25),(90,30)],3)
        for y in [58,70]:line([(46,y),(82,y)],2)
        line([(64,47),(64,87)],2)
    elif key in ['Gearhead','QueenOfTheHighway','EasyComeEasyGo']:
        polygon([(32,53),(43,35),(82,35),(94,53)]);d.rounded_rectangle((27,51,101,77),radius=5,outline=c,width=4)
        d.rectangle((35,75,45,88),fill=c);d.rectangle((84,75,94,88),fill=c);line([(43,53),(84,53)],3);ellipse((35,59,45,69));ellipse((83,59,93,69))
    elif key in ['MaxPain','Specialist']:
        ellipse((32,25,96,89),4);line([(64,31),(64,57),(83,66)],4)
        for i in range(12):
            a=i*math.pi/6;line([(64+27*math.cos(a),57+27*math.sin(a)),(64+30*math.cos(a),57+30*math.sin(a))],2)
    elif key in ['AllThePresidentsMen','FollowingTheRiver']:
        line([(64,25),(93,36),(89,67),(78,81),(64,91),(50,81),(39,67),(35,36),(64,25)],4);polygon(star(64,53,19))
    elif key=='TheHightPriestess':
        ellipse((37,27,91,86),4);d.ellipse((51,23,99,75),fill=(16,24,35));polygon(star(83,76,11))
    elif key=='TheHermit':
        line([(57,36),(57,28),(72,28),(72,36)],3);d.rectangle((44,36,85,82),outline=c,width=3);line([(44,36),(64,49),(85,36)],2);line([(44,82),(64,66),(85,82)],2);polygon([(64,44),(72,63),(64,73),(57,63)])
    elif key=='Temperance':
        line([(64,27),(64,85)],4);line([(37,45),(91,45)],4);line([(42,45),(31,68),(53,68),(42,45)],2);line([(86,45),(75,68),(97,68),(86,45)],2);line([(46,87),(82,87)],4)
    elif key=='TheFool':
        ellipse((59,25,73,39),3);line([(65,40),(60,62),(48,83)],5);line([(60,62),(77,83)],5);line([(62,47),(45,52),(36,41)],4);line([(63,47),(83,42)],4);line([(82,40),(89,24)],3);d.ellipse((84,20,98,34),fill=c)
    elif key=='NeverFadeAway':
        line([(47,28),(58,37),(70,37),(81,28),(99,49),(86,59),(81,50),(81,87),(47,87),(47,50),(42,59),(29,49),(47,28)],4);line([(64,39),(64,86)],2)
    elif key=='BornToBeWild':
        ellipse((38,57,66,88),4);ellipse((56,45,80,72),4);line([(66,60),(88,28)],8);line([(81,25),(96,35)],6)
    elif key=='UnderPressure':
        for y in [38,56,74]:
            pts=[(x,y+6*math.sin((x-30)/10)) for x in range(30,100)];line(pts,3)
    elif key=='Roleplayer':
        d.rounded_rectangle((30,29,96,72),radius=7,outline=c,width=3);line([(45,72),(42,87),(62,72)],3)
        for x in [45,63,81]:d.ellipse((x-3,48,x+3,54),fill=c)
    elif key=='TwoHeadsOneBullet':
        ellipse((32,31,58,57),4);ellipse((70,31,96,57),4);line([(24,70),(100,70)],3);polygon([(101,70),(91,64),(91,76)])
    elif key=='ThatIsSoHardForTheKnees':
        polygon([(57,26),(71,26),(71,58),(86,58),(64,80),(42,58),(57,58)]);line([(30,91),(45,82),(53,89),(64,83),(76,90),(84,83),(98,91)],3)
    elif key=='Fortuneteller':
        d.rounded_rectangle((42,24,86,89),radius=4,outline=c,width=3);polygon(star(64,56,17));line([(51,32),(77,32)],2);line([(51,81),(77,81)],2)
    elif key=='HandyMan':
        ellipse((67,27,96,56),4);line([(72,51),(39,84)],12);ellipse((33,77,45,89),2)
    elif key=='IHateSpider':
        ellipse((51,43,77,74),4)
        for side in [-1,1]:
            for i in range(4):line([(64+side*12,49+i*5),(64+side*28,30+i*15),(64+side*38,36+i*15)],3)
    elif key=='MustBeTheRats':
        ellipse((40,43,88,82),3);ellipse((32,28,55,52),3);ellipse((73,28,96,52),3);d.ellipse((50,56,55,61),fill=c);d.ellipse((73,56,78,61),fill=c);polygon([(59,68),(69,68),(64,75)])
    else:
        # DirtyWork etc.: contract document.
        d.rectangle((41,26,87,90),outline=c,width=3)
        for y in [40,53,66]:line([(50,y),(78,y)],3)
        polygon(star(76,79,15))
