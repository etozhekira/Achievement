"""Build Russian catalog and original per-achievement artwork from verified Steam IDs."""
import json, hashlib, math, random
from artwork import emblem
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
root=Path(__file__).resolve().parents[1]
source=root/'docs'/'steam-schema-reference.json'
schema=json.loads(source.read_text())
# Russian editorial translation of public Steam schema, hidden conditions supplied explicitly.
text='''TheFool|Шут|Станьте наёмником.
TheLovers|Влюблённые|Украдите биочип.
TheHermit|Отшельник|Найдите Альт Каннингем.
TheWheelOfFortune|Колесо фортуны|Допросите Андерса Хелльмана.
TheHightPriestess|Верховная жрица|Поговорите с Ханако Арасакой.
TheWorld|Мир|Завершите основную сюжетную линию.
TheDevil|Дьявол|Помогите Такэмуре отомстить за смерть Сабуро Арасаки.
TheStar|Звезда|Покиньте Найт-Сити вместе с Альдекальдо.
TheSun|Солнце|Станьте легендой «Посмертия».
Temperance|Умеренность|Позвольте Джонни Сильверхенду оставить себе ваше тело.
FollowingTheRiver|Защищать и служить|Завершите сюжетную линию Ривера Уорда.
BornToBeWild|За плохие решения!|Завершите сюжетную линию Керри Евродина.
UnderPressure|Джуди против Найт-Сити|Завершите сюжетную линию Джуди Альварес.
QueenOfTheHighway|Жизнь в дороге|Завершите сюжетную линию Панам Палмер.
BushidoAndChill|Бусидо и чилл|Посмотрите «Бусидо X» вместе с Бестией.
NeverFadeAway|Потрясающе!|Соберите все вещи, принадлежавшие Джонни Сильверхенду.
YipMan|Это элементарно|Завершите все заказы и расследования NCPD в Уотсоне.
IAmMaxTac|Я — закон|Завершите все задания по поиску киберпсихопатов.
ThisIsPacifica|Привет из Пасифики!|Завершите все заказы и расследования NCPD в Пасифике.
NoMansLand|Пустошь|Завершите все заказы и расследования NCPD в Пустошах.
LittleTokyo|Маленький Токио|Завершите все заказы и расследования NCPD в Уэстбруке.
LikeFatherLikeSon|Злые улицы|Завершите все заказы и расследования NCPD в Хейвуде.
TradeUnion|Джунгли|Завершите все заказы и расследования NCPD в Санто-Доминго.
Bladerunner|Огни большого города|Завершите все заказы и расследования NCPD в городском центре.
Cyberjunkie|Полная конверсия|Установите хотя бы один имплант в каждую систему и часть тела.
GunKata|Ган-фу|Быстро убейте или обезвредьте 3 врагов из пистолета или револьвера в ближнем бою.
MasterRunner|Атака рождественской ёлки|Загрузите не менее 3 демонов за один взлом протокола.
Specialist|Десять из десяти|Достигните максимального уровня любого навыка.
Gunslinger|Стрелок|Подстрелите вражескую гранату в полёте из револьвера.
TwoHeadsOneBullet|Две головы — одна пуля|Убейте или обезвредьте 2 врагов одним выстрелом из снайперской винтовки.
ThatIsSoHardForTheKnees|Жёсткая посадка|Во время действия «Берсерка» убейте или обезвредьте 2 врагов супергеройским приземлением.
Roleplayer|Метод Станиславского|10 раз выберите реплику, связанную с происхождением Ви.
Gearhead|Автоколлекционер|Купите все доступные для покупки автомобили.
HandyMan|Мастер-ремесленник|Создайте 3 легендарных предмета.
NotTheMobile|Демон в оболочке|Убейте или обезвредьте 3 врагов одним скриптом «Взрыв гранаты».
MaxPain|Быстрый и мёртвый|Убейте или обезвредьте 50 врагов во время замедления времени.
MustBeTheRats|Наверное, крысы|30 раз используйте скрипт «Отвлечение врагов», не привлекая внимания.
VForVendetta|V значит вендетта|После оживления «Вторым сердцем» за 5 секунд убейте или обезвредьте убившего вас врага.
TrueSoldier|Настоящий солдат|Убейте или обезвредьте 300 врагов оружием дальнего боя.
TrueWarrior|Настоящий воин|Убейте или обезвредьте 100 врагов оружием ближнего боя.
Denied|Обратная доставка|Убейте или обезвредьте врага, бросившего в вас гранату.
Fortuneteller|Бродячий шут|Найдите все граффити таро для задания «Шут из Найт-Сити».
GetMeThereScottie|Частый путешественник|Найдите все терминалы быстрого перемещения.
YouKnowWhoIAm|Легенда «Посмертия»|Достигните максимального уровня репутации.
KingOfTheCups|Король кубков|В финале истории Сойки исполните её просьбу.
KingOfThePentacles|Король пентаклей|В ветке помощи Риду откажите Сойке в её последней просьбе.
KingOfTheWands|Король жезлов|Помогите Сойке отправиться на Луну.
KingOfTheSwords|Король мечей|В ветке помощи Сойке передайте её Риду.
TheTower|Башня|Завершите новую основную концовку после лечения Ви.
Kingmaker|Политтехнолог|Завершите задание «Междуцарствие».
AllThePresidentsMen|Вся президентская рать|Спасите президента Майерс.
DirtyWork|Грязные делишки|Завершите все заказы в Пёсьем городе.
HydraIsDead|Судный день|Устраните трёх боссов в зонах повышенной преступной активности.
EasyComeEasyGo|Легко пришло — легко ушло|Украдите медицинский грузовик «Арасаки» или доставьте 10 автомобилей Эль-Капитану.
IHateSpider|Арахнофобия|Победите «Химеру».
RelicMaster|Повелитель биочипа|Откройте все способности в дереве биочипа.
DogtownLaw|Особо опасен|Получите максимальный уровень розыска в Пёсьем городе.'''
ru={r.split('|')[0]:r.split('|')[1:] for r in text.splitlines()}
assert len(ru)==57 and set(ru)=={a['name'] for a in schema}
dlc={a['name'] for a in schema[44:]}
rows=[]
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
font=ImageFont.truetype(font_path,18)
for i,a in enumerate(schema):
 key=a['name']; label,desc=ru[key]
 rows.append({'id':key,'label':label,'description':desc,'dlc':key in dlc,'number':i+1,'steamName':a['displayName'],'steamDescription':a['description'],'steamIcon':a['icon'],'artwork':'original'})
 # Original neon badge: unique circuitry, central trophy, catalog number.
 rng=random.Random(key);im=Image.new('RGB',(128,128),(12,20,30));d=ImageDraw.Draw(im)
 accent=(250,226,64) if key not in dlc else (68,231,225)
 for y in range(128):d.line((0,y,128,y),fill=(12+y//20,20+y//15,30+y//12))
 for j in range(8):
  y=rng.randrange(8,120);x=rng.randrange(4,38);d.line([(x,y),(x+10,y),(x+19,y-9),(110,y-9)],fill=tuple(c//4 for c in accent),width=1)
 pts=[(64+51*math.cos(math.pi/3*j-math.pi/6),60+51*math.sin(math.pi/3*j-math.pi/6)) for j in range(6)]
 d.line(pts+[pts[0]],fill=accent,width=2)
 emblem(d,key,accent)
 d.rectangle((41,96,87,120),fill=(12,20,30));d.text((64,107),f'{i+1:02}',font=font,fill=accent,anchor='mm')
 im.save(root/'assets'/f'{key}.png')
(root/'catalog.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(root/'docs'/'steam-schema-reference.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2))
print('57 verified Steam IDs, 13 PL, 57 original PNG icons')

# Apply the Russian wording supplied in the screenshot references.
import update_catalog_refs
