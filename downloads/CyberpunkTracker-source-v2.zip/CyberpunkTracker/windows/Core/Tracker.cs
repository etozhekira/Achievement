using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace CyberpunkTracker;
public sealed class Achievement {
 public string Id {get;set;}=""; public string Label {get;set;}="";
 public string Description {get;set;}=""; public bool Dlc {get;set;}
 public string Tracking {get;set;}="";
 public int Number {get;set;}
}
public sealed class Evidence {
 public string Source {get;set;}=""; public string Detail {get;set;}="";
 public DateTimeOffset At {get;set;}=DateTimeOffset.Now;
}
public sealed class Session {
 public Guid Id {get;set;}=Guid.NewGuid(); public DateTimeOffset Started {get;set;}=DateTimeOffset.Now;
 public DateTimeOffset? Ended {get;set;} public double Seconds {get;set;}
}
public sealed class Settings {
 public int Version {get;set;}=3;
 public double BaselineSeconds {get;set;}=48600.5853114;
 public string BaselineSource {get;set;}="Приложенный metadata.9.json: playTime";
 public bool MetadataBaselineApplied {get;set;}=true;
 public bool Dlc {get;set;}=true; public bool Notifications {get;set;}=true;
 public bool HistoricalNotifications {get;set;}=false;
 public string SaveFolder {get;set;}=""; public string LogPath {get;set;}="";
 public string GameFolder {get;set;}="";
 public List<Session> Sessions {get;set;}=[];
 public long LastProgressSaveUtcTicks {get;set;}
 public Dictionary<string,LocalProgress> Progress {get;set;}=[];
 public Dictionary<string,List<Evidence>> Achievements {get;set;}=[];
}
public sealed class LocalProgress {public int Current {get;set;} public int? Target {get;set;} public string Source {get;set;}="сейв";}
public record ImportResult(int Added, string Message);
public sealed class Engine : IDisposable {
 public static readonly JsonSerializerOptions Json = new(){PropertyNameCaseInsensitive=true,WriteIndented=true,PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
 public Settings Data {get;private set;}
 public IReadOnlyList<Achievement> Catalog {get;}
 public string StatePath {get;}
 public bool Running {get;private set;}
 public event Action<Achievement,string>? Unlocked;
 private Session? active; private double last;
 private readonly Stopwatch clock=Stopwatch.StartNew();
 private readonly HashSet<string> ids;
 private readonly Dictionary<string,(long Length,long Write)> seen=[];
 private readonly Dictionary<string,LogCursor> cursors=[];
 private sealed class LogCursor {public long Offset;public string Pending="";public string Prefix="";}
 public Engine(string statePath,IReadOnlyList<Achievement> catalog) {
  StatePath=statePath;Catalog=catalog;ids=catalog.Select(a=>a.Id).ToHashSet(StringComparer.Ordinal);
  Data=File.Exists(statePath)?JsonSerializer.Deserialize<Settings>(File.ReadAllText(statePath),Json)??throw new InvalidDataException("Пустой файл состояния"):new();
  if(!double.IsFinite(Data.BaselineSeconds)||Data.BaselineSeconds<0||Data.Sessions.Any(s=>!double.IsFinite(s.Seconds)||s.Seconds<0))throw new InvalidDataException("Некорректное время в файле состояния");
  Data.Version=3;
  foreach(var s in Data.Sessions.Where(s=>s.Ended==null))s.Ended=s.Started.AddSeconds(s.Seconds);
 }
 public double TotalSeconds=>Data.BaselineSeconds+Data.Sessions.Sum(s=>s.Seconds);
 public static string Duration(double seconds) {var t=TimeSpan.FromSeconds(Math.Max(0,seconds));return $"{(long)t.TotalHours} ч {t.Minutes:00} мин {t.Seconds:00} с";}
 public void Tick(bool running,double? monotonic=null) {
  var now=monotonic??clock.Elapsed.TotalSeconds;
  if(Running&&active!=null)active.Seconds+=Math.Clamp(now-last,0,5);
  if(running&&!Running){active=new();Data.Sessions.Add(active);}
  if(!running&&active!=null){active.Ended=DateTimeOffset.Now;active=null;}
  Running=running;last=now;
 }
 public void SetBaseline(double hours) {
  if(!double.IsFinite(hours)||hours<0||hours>100000)throw new ArgumentException("Укажите часы от 0 до 100000");
  Data.BaselineSeconds=hours*3600;Data.BaselineSource="Вручную";Data.MetadataBaselineApplied=true;Save();
 }
 public bool Confirm(string id,string source,string detail,bool notify=false) {
  if(!ids.Contains(id))return false;
  bool first=!Data.Achievements.TryGetValue(id,out var records)||records.Count==0;
  if(records==null)Data.Achievements[id]=records=[];
  if(records.Any(e=>e.Source==source&&e.Detail==detail))return false;
  records.Add(new(){Source=source,Detail=detail});
  // Persist before displaying a toast so a restart cannot repeat it.
  Save();if(first&&notify&&Data.Notifications)Unlocked?.Invoke(Catalog.First(a=>a.Id==id),source);
  return first;
 }
 public void RemoveManual(string id) {if(Data.Achievements.TryGetValue(id,out var e))e.RemoveAll(r=>r.Source=="вручную");Save();}
 public ImportResult Import(string path,bool notify=false) {
  if(Path.GetExtension(path).Equals(".dat",StringComparison.OrdinalIgnoreCase))return ImportSave(path,notify);
  using var doc=JsonDocument.Parse(ReadShared(path));var root=doc.RootElement;int added=0;
  if(root.ValueKind==JsonValueKind.Object&&root.TryGetProperty("classes",out _)&&root.TryGetProperty("enums",out _))return new(0,"Описание API: время и разблокировки отсутствуют.");
  if(root.ValueKind==JsonValueKind.Object&&root.TryGetProperty("RootType",out var type)&&type.GetString()=="saveMetadataContainer") {
   var m=root.GetProperty("Data").GetProperty("metadata");
   var info="Метаданные сейва прочитаны.";
   if(m.TryGetProperty("playTime",out var p)&&p.TryGetDouble(out var seconds)&&double.IsFinite(seconds)&&seconds>=0) {
    info+=" Время сейва: "+Duration(seconds)+".";
    if(!Data.MetadataBaselineApplied) {Data.BaselineSeconds=seconds;Data.MetadataBaselineApplied=true;Data.BaselineSource=path+": playTime";}
   }
   if(m.TryGetProperty("finishedQuests",out var q)) {
    var quests=(q.GetString()??"").Split(' ',StringSplitOptions.RemoveEmptyEntries).ToHashSet();
    foreach(var rule in new[]{("q001","TheFool"),("q005","TheLovers"),("q104","TheWheelOfFortune")})
     if(quests.Contains(rule.Item1)&&Confirm(rule.Item2,"сейв",Path.GetFullPath(path)+": finishedQuests/"+rule.Item1,notify))added++;
   }
   if(m.TryGetProperty("streetCred",out var cred)&&cred.TryGetDouble(out var rep)&&rep==50)
    if(Confirm("YouKnowWhoIAm","сейв",Path.GetFullPath(path)+": streetCred=50",notify))added++;
   Save();return new(added,info+$" Новых отметок: {added}.");
  }
  var rows=root;
  if(root.ValueKind==JsonValueKind.Object&&root.TryGetProperty("achievements",out var a))rows=a;
  if(rows.ValueKind==JsonValueKind.Array) {
   foreach(var row in rows.EnumerateArray()) {
    if(row.ValueKind==JsonValueKind.Object&&row.TryGetProperty("id",out var id)&&row.TryGetProperty("unlocked",out var u)&&u.ValueKind==JsonValueKind.True)
     if(Confirm(id.GetString()??"","журнал",Path.GetFullPath(path),notify))added++;
   }
  } else if(rows.ValueKind==JsonValueKind.Object) {
   // Supported emulator JSON map: exact API IDs only, earned=true or boolean true.
   foreach(var prop in rows.EnumerateObject()) {
    var v=prop.Value;bool earned=v.ValueKind==JsonValueKind.True ||
      (v.ValueKind==JsonValueKind.Object&&v.TryGetProperty("earned",out var e)&&e.ValueKind==JsonValueKind.True);
    if(earned&&Confirm(prop.Name,"журнал",Path.GetFullPath(path),notify))added++;
   }
  } else throw new InvalidDataException("Неизвестный формат JSON. Файл не изменён.");
  Save();return new(added,$"Импорт завершён. Новых подтверждений: {added}. Неизвестные ID пропущены.");
 }
 public ImportResult ImportSave(string path,bool notify=false){
  var facts=SaveFacts.Read(path);int added=0;
  int? Fact(string name)=>facts.TryGetValue(SaveFacts.Hash(name),out int n)?n:null;
  foreach(var rule in new[]{("q001_done","TheFool"),("q005_done","TheLovers"),("q104_done","TheWheelOfFortune"),("q110_done","TheHermit")})
   if(Fact(rule.Item1)==1&&Confirm(rule.Item2,"сейв",Path.GetFullPath(path)+": "+rule.Item1+"=1",notify))added++;
  long saveTime=File.GetLastWriteTimeUtc(path).Ticks;
  if(saveTime>=Data.LastProgressSaveUtcTicks){
  if(Fact("mq033_grafitti_counter") is int tarot&&tarot>=0&&tarot<=22)Data.Progress["Fortuneteller"]=new(){Current=tarot,Target=20};
  if(Fact("sq025_scans_done") is int cars&&cars>=0&&cars<=7)Data.Progress["mission_delamain"]=new(){Current=cars,Target=7};
  Data.LastProgressSaveUtcTicks=saveTime;
  }
  Save();return new(added,$"Сейв прочитан: {facts.Count} квестовых флагов. Новых подтверждений: {added}.");
 }
 public int ReadLog(string path,bool notify=true) {
  using var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete);
  if(!cursors.TryGetValue(path,out var cursor))cursors[path]=cursor=new();
  var prefixBytes=new byte[(int)Math.Min(128,file.Length)];file.ReadExactly(prefixBytes);
  string prefix=Convert.ToHexString(prefixBytes);
  bool first=cursor.Offset==0;
  if(file.Length<cursor.Offset || (cursor.Prefix.Length>0&&!prefix.StartsWith(cursor.Prefix,StringComparison.Ordinal))) {cursor.Offset=0;cursor.Pending="";first=true;}
  cursor.Prefix=prefix;
  file.Position=cursor.Offset;
  using var reader=new StreamReader(file,Encoding.UTF8,true,4096,true);
  string text=cursor.Pending+reader.ReadToEnd();cursor.Offset=file.Length;
  var lines=text.Split('\n');cursor.Pending=lines[^1];int count=0;
  foreach(var line in lines.SkipLast(1)) {
   if(line.Length>16384)continue;
   try {
    using var doc=JsonDocument.Parse(line.TrimStart('\uFEFF'));var r=doc.RootElement;
    if(r.TryGetProperty("event",out var ev)&&ev.GetString()=="achievement_unlocked"&&r.TryGetProperty("id",out var id))
     if(Confirm(id.GetString()??"","журнал",Path.GetFullPath(path),notify&&(!first||Data.HistoricalNotifications)))count++;
   }catch(JsonException){}
  }
  if(cursor.Pending.Length>16384)cursor.Pending="";
  return count;
 }
 public List<string> Scan() {
  var messages=new List<string>();
  if(!string.IsNullOrWhiteSpace(Data.LogPath)) {
   try {
    if(!File.Exists(Data.LogPath))messages.Add("Журнал ещё не создан: ожидаю события CET.");
    else if(Path.GetExtension(Data.LogPath).Equals(".json",StringComparison.OrdinalIgnoreCase))Poll(Data.LogPath,()=>Import(Data.LogPath,true));
    else ReadLog(Data.LogPath);
   }catch(Exception e){messages.Add("Журнал: "+e.Message);}
  }
  if(Directory.Exists(Data.SaveFolder)) {
   try {
    foreach(var f in Directory.EnumerateFiles(Data.SaveFolder,"*",SearchOption.AllDirectories).Where(p=>Path.GetFileName(p)=="sav.dat"||Path.GetFileName(p).StartsWith("metadata",StringComparison.OrdinalIgnoreCase)&&Path.GetExtension(p).Equals(".json",StringComparison.OrdinalIgnoreCase)).OrderBy(File.GetLastWriteTimeUtc))
     try{Poll(f,()=>Import(f,true));}catch(Exception e){messages.Add(Path.GetFileName(f)+": "+e.Message);}
   }catch(Exception e){messages.Add("Сейвы: "+e.Message);}
  }
  return messages;
 }
 private void Poll(string path,Action action) {
  var f=new FileInfo(path);var sig=(f.Length,f.LastWriteTimeUtc.Ticks);
  if(seen.TryGetValue(path,out var old)&&old==sig)return;
  // Wait until a file has stopped changing for a moment.
  if(DateTime.UtcNow-f.LastWriteTimeUtc<TimeSpan.FromSeconds(1))return;
  action();seen[path]=sig;
 }
 public static string ReadShared(string path) {
  using var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete);
  if(f.Length>32*1024*1024)throw new InvalidDataException("JSON превышает 32 МБ");
  using var r=new StreamReader(f,Encoding.UTF8,true);return r.ReadToEnd();
 }
 public void Save() {
  Directory.CreateDirectory(Path.GetDirectoryName(StatePath)!);
  var temp=StatePath+".tmp";
  using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)) {
   JsonSerializer.Serialize(f,Data,Json);f.Flush(true);
  }
  if(File.Exists(StatePath))File.Copy(StatePath,StatePath+".bak",true);
  File.Move(temp,StatePath,true);
 }
 public void Dispose(){Tick(false);Save();}
}
