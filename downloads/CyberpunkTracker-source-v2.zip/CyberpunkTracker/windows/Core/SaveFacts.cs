using System.Buffers.Binary;
using System.Text;
namespace CyberpunkTracker;

// Independent, read-only parser for the CSAV chunk/node/FactsTable format.
// It deliberately does not interpret opaque AchievementSystem bytes as unlocks.
public static class SaveFacts {
 const int Limit=128*1024*1024;
 public static uint Hash(string text){uint h=2166136261;foreach(byte b in Encoding.UTF8.GetBytes(text))h=unchecked((h^b)*16777619);return h;}
 public static Dictionary<uint,int> Read(string path){using var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete);if(f.Length>32*1024*1024)throw new InvalidDataException("Сейв превышает 32 МБ");var data=new byte[(int)f.Length];f.ReadExactly(data);return Parse(data);}
 static int Int(byte[] d,int p){Bounds(d,p,4);return BinaryPrimitives.ReadInt32LittleEndian(d.AsSpan(p,4));}
 static void Bounds(byte[] d,int p,int n){if(p<0||n<0||p>d.Length-n)throw new InvalidDataException("Повреждённые границы сейва");}
 static bool Tag(byte[] d,int p,string s){Bounds(d,p,s.Length);return Encoding.ASCII.GetString(d,p,s.Length)==s;}
 static int Packed(byte[] d,ref int p){Bounds(d,p,1);byte a=d[p++];long v=a&63;bool negative=(a&128)!=0;if((a&64)!=0){for(int shift=6;shift<=27;shift+=7){Bounds(d,p,1);a=d[p++];v|=(long)(a&(shift==27?255:127))<<shift;if((a&128)==0)break;}}if(v>int.MaxValue)throw new InvalidDataException("Слишком большое packed-значение");return negative?-(int)v:(int)v;}
 static string Text(byte[] d,ref int p){int n=Packed(d,ref p);if(Math.Abs((long)n)>4096)throw new InvalidDataException("Слишком длинная строка узла");int bytes=n<0?-n:checked(n*2);Bounds(d,p,bytes);string s=(n<0?Encoding.UTF8:Encoding.Unicode).GetString(d,p,bytes);p+=bytes;return s;}
 public static Dictionary<uint,int> Parse(byte[] d){
  if(d.Length<40||!Tag(d,0,"VASC")||!Tag(d,d.Length-4,"ENOD"))throw new InvalidDataException("Не поддерживаемый заголовок CSAV");
  int p=12;Text(d,ref p);p+=12;if(!Tag(d,p,"FZLC"))throw new InvalidDataException("Не найден блок сжатия CSAV");int count=Int(d,p+4);if(count<1||count>2048)throw new InvalidDataException("Некорректное число блоков");
  var chunks=new List<(int Offset,int Size,int Raw)>();
  for(int i=0;i<count;i++){int k=p+8+i*12;int off=Int(d,k),size=Int(d,k+4),raw=Int(d,k+8);Bounds(d,off,size);if(raw<=0||raw>0x40000||size<8)throw new InvalidDataException("Некорректный блок");chunks.Add((off,size,raw));}
  chunks.Sort((a,b)=>a.Offset.CompareTo(b.Offset));long length=(long)chunks[0].Offset+chunks.Sum(c=>(long)c.Raw);if(length>Limit)throw new InvalidDataException("Распакованный сейв превышает 128 МБ");var output=new byte[(int)length];int target=chunks[0].Offset;
  foreach(var c in chunks){if(!Tag(d,c.Offset,"4ZLX")||Int(d,c.Offset+4)!=c.Raw)throw new InvalidDataException("Не поддерживаемый блок LZ4");DecodeLz4(d.AsSpan(c.Offset+8,c.Size-8),output.AsSpan(target,c.Raw));target+=c.Raw;}
  int footer=Int(d,d.Length-8);if(!Tag(d,footer,"EDON"))throw new InvalidDataException("Нет таблицы узлов");p=footer+4;int nodes=Packed(d,ref p);if(nodes<1||nodes>100000)throw new InvalidDataException("Некорректное число узлов");var result=new Dictionary<uint,int>();var ambiguous=new HashSet<uint>();int tables=0;
  for(int i=0;i<nodes;i++){
   string name=Text(d,ref p);Bounds(d,p,16);int offset=Int(d,p+8),size=Int(d,p+12);p+=16;Bounds(output,offset,size);if(size<4||Int(output,offset)!=i)throw new InvalidDataException("Индекс узла не совпадает");
   if(name!="FactsTable")continue;tables++;int q=offset+4;int n=Packed(output,ref q);if(n<0||n>1000000||(long)q+8L*n!=offset+(long)size)throw new InvalidDataException("Неизвестный формат FactsTable");
   for(int j=0;j<n;j++){uint hash=unchecked((uint)Int(output,q+4*j));int value=Int(output,q+4*n+4*j);if(ambiguous.Contains(hash))continue;if(result.TryGetValue(hash,out var old)&&old!=value){result.Remove(hash);ambiguous.Add(hash);continue;}result[hash]=value;}
  }
  if(p!=d.Length-8||tables==0)throw new InvalidDataException("Не поддерживаемая таблица фактов");return result;
 }
 public static void DecodeLz4(ReadOnlySpan<byte> input,Span<byte> output){
  int i=0,o=0;while(i<input.Length){byte token=input[i++];int literals=token>>4;if(literals==15){int b;do{if(i>=input.Length)throw new InvalidDataException("Обрезанный LZ4");b=input[i++];literals=checked(literals+b);}while(b==255);}
   if(literals>input.Length-i||literals>output.Length-o)throw new InvalidDataException("Некорректные литералы LZ4");input.Slice(i,literals).CopyTo(output.Slice(o));i+=literals;o+=literals;if(i==input.Length)break;
   if(i+2>input.Length)throw new InvalidDataException("Обрезанная ссылка LZ4");int offset=input[i]|input[i+1]<<8;i+=2;if(offset==0||offset>o)throw new InvalidDataException("Некорректная ссылка LZ4");int match=(token&15)+4;if((token&15)==15){int b;do{if(i>=input.Length)throw new InvalidDataException("Обрезанный LZ4 match");b=input[i++];match=checked(match+b);}while(b==255);}
   if(match>output.Length-o)throw new InvalidDataException("Переполнение LZ4");for(int j=0;j<match;j++){output[o]=output[o-offset];o++;}
  }if(o!=output.Length)throw new InvalidDataException("Размер LZ4 не совпадает");
 }
}
