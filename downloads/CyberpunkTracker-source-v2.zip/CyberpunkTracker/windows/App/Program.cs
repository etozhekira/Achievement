using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;
using CyberpunkTracker;

internal static class Program {
 [STAThread] static void Main() {
  ApplicationConfiguration.Initialize();
  using var mutex=new Mutex(true,"Local\\CyberpunkLocalTrackerV2",out var created);
  if(!created){MessageBox.Show("Программа уже открыта. Найдите её значок рядом с часами.","Cyberpunk Tracker");return;}
  try {Application.Run(new MainForm());}
  catch(Exception e){MessageBox.Show("Не удалось запустить программу. Данные не сброшены.\n"+e.Message,"Ошибка",MessageBoxButtons.OK,MessageBoxIcon.Error);}
 }
}
internal static class Art {
 public static readonly Color Bg=Color.FromArgb(13,17,24), Panel=Color.FromArgb(23,30,40), Cyan=Color.FromArgb(61,226,229), Yellow=Color.FromArgb(245,235,61), Muted=Color.FromArgb(157,171,188);
 public static Image Load(string name) {
  var asm=Assembly.GetExecutingAssembly();var resource=asm.GetManifestResourceNames().First(n=>n.EndsWith(name,StringComparison.Ordinal));
  using var stream=asm.GetManifestResourceStream(resource)!;using var image=Image.FromStream(stream);return new Bitmap(image);
 }
 public static Button Button(string text,EventHandler click) {
  var b=new Button{Text=text,AutoSize=true,Height=36,MinimumSize=new(40,36),FlatStyle=FlatStyle.Flat,BackColor=Panel,ForeColor=Color.White,Padding=new(8,0,8,0),Margin=new(0,0,8,8)};
  b.FlatAppearance.BorderColor=Color.FromArgb(54,74,86);b.Click+=click;return b;
 }
}
public sealed class MainForm : Form {
 readonly Engine engine;
 readonly Dictionary<string,Image> icons=[];
 readonly Label total=new(), gameStatus=new(), progress=new(), footer=new();
 readonly ProgressBar progressBar=new(){Minimum=0,Maximum=1000,Style=ProgressBarStyle.Continuous};
 readonly Panel content=new(){Dock=DockStyle.Fill};
 readonly FlowLayoutPanel missions=new(){Dock=DockStyle.Fill,AutoScroll=true,FlowDirection=FlowDirection.TopDown,WrapContents=false};
 readonly FlowLayoutPanel tools=new(){Dock=DockStyle.Fill,WrapContents=false};
 bool missionPage;
 readonly Button navigation=Art.Button("Разблокировать",(_,_)=>{});
 readonly TextBox search=new(); readonly ComboBox filter=new();
 readonly FlowLayoutPanel cards=new(); readonly CheckBox pl=new(),notifications=new();
 readonly System.Windows.Forms.Timer timer=new(){Interval=1000};
 readonly NotifyIcon tray;
 readonly Queue<(Achievement,string)> toasts=[];
 Toast? toast;bool busy;int tick;string signature="";bool initialScan=true;
 public MainForm() {
  Text="Cyberpunk 2077 • Локальные достижения v2";Size=new(1150,820);MinimumSize=new(1080,720);StartPosition=FormStartPosition.CenterScreen;
  BackColor=Art.Bg;ForeColor=Color.White;Font=new("Segoe UI",10);AutoScaleMode=AutoScaleMode.Dpi;
  var asm=Assembly.GetExecutingAssembly();using var stream=asm.GetManifestResourceStream(asm.GetManifestResourceNames().First(n=>n.EndsWith("catalog.json")))!;
  var catalog=JsonSerializer.Deserialize<List<Achievement>>(stream,Engine.Json)!;
  foreach(var a in catalog)icons[a.Id]=Art.Load(a.Id+".png");
  var folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CyberpunkLocalTracker");
  string state=Path.Combine(folder,"state-v2.json");bool firstRun=!File.Exists(state);
  engine=new(state,catalog);
  if(firstRun){engine.Data.Progress["Fortuneteller"]=new(){Current=8,Target=20};engine.Data.Progress["mission_delamain"]=new(){Current=4,Target=7};engine.Confirm("TheFool","сейв","Приложенный metadata.9.json: finishedQuests/q001");engine.Confirm("TheLovers","сейв","Приложенный metadata.9.json: finishedQuests/q005");engine.Confirm("TheWheelOfFortune","сейв","Приложенный metadata.9.json: finishedQuests/q104");}
  if(string.IsNullOrEmpty(engine.Data.SaveFolder)) {
   string saves=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Saved Games","CD Projekt Red","Cyberpunk 2077");
   if(Directory.Exists(saves))engine.Data.SaveFolder=saves;
  }
  var layout=new TableLayoutPanel{Dock=DockStyle.Fill,RowCount=6,ColumnCount=1,Padding=new(22)};
  layout.RowStyles.Add(new(SizeType.Absolute,147));layout.RowStyles.Add(new(SizeType.Absolute,52));layout.RowStyles.Add(new(SizeType.Absolute,52));layout.RowStyles.Add(new(SizeType.Absolute,45));layout.RowStyles.Add(new(SizeType.Percent,100));layout.RowStyles.Add(new(SizeType.Absolute,62));Controls.Add(layout);
  var header=new Panel{Dock=DockStyle.Fill};layout.Controls.Add(header,0,0);
  var title=new Label{Text="CYBERPUNK 2077",ForeColor=Art.Yellow,Font=new("Segoe UI",22,FontStyle.Bold),AutoSize=true,Location=new(0,0)};
  total.Font=new("Segoe UI",15,FontStyle.Bold);total.AutoSize=true;total.Location=new(0,43);
  gameStatus.AutoSize=true;gameStatus.ForeColor=Art.Muted;gameStatus.Anchor=AnchorStyles.Top|AnchorStyles.Right;gameStatus.Location=new(650,14);
  progress.AutoSize=true;progress.ForeColor=Art.Muted;progress.Location=new(0,78);
  progressBar.Location=new(0,108);progressBar.Size=new(1040,12);progressBar.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;
  header.Controls.AddRange([title,total,gameStatus,progress,progressBar]);header.Resize+=(_,_)=>gameStatus.Left=header.Width-gameStatus.Width-5;
  var buttons=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};layout.Controls.Add(buttons,0,1);
  navigation.Click+=(_,_)=>{missionPage=!missionPage;navigation.Text=missionPage?"← Достижения":"Разблокировать";cards.Visible=!missionPage;missions.Visible=missionPage;tools.Visible=!missionPage;if(missionPage)RenderMissions();};
  buttons.Controls.Add(navigation);
  buttons.Controls.AddRange([
   Art.Button("Импорт JSON",(_,_)=>Import()),Art.Button("Стартовое время",(_,_)=>Baseline()),
   Art.Button("Сессии",(_,_)=>Sessions()),Art.Button("Папка данных",(_,_)=>OpenFolder(folder)),
   Art.Button("Проверить уведомление",(_,_)=>QueueToast(catalog[0],"Проверка • статус не меняется")),
   Art.Button("В трей",(_,_)=>{Hide();tray!.ShowBalloonTip(1800,"Cyberpunk Tracker","Таймер продолжает работать. Двойной щелчок — открыть.",ToolTipIcon.Info);})]);
  var settings=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};layout.Controls.Add(settings,0,2);
  settings.Controls.AddRange([Art.Button("Папка игры",(_,_)=>GameFolder()),Art.Button("Папка сейвов",(_,_)=>SaveFolder()),Art.Button("Выбрать журнал",(_,_)=>LogFile()),Art.Button("Подключение CET",(_,_)=>CetHelp())]);
  pl.Text="Phantom Liberty";pl.Checked=engine.Data.Dlc;pl.AutoSize=true;pl.Margin=new(12,9,12,0);
  notifications.Text="Уведомления";notifications.Checked=engine.Data.Notifications;notifications.AutoSize=true;notifications.Margin=new(0,9,0,0);
  pl.CheckedChanged+=(_,_)=>{engine.Data.Dlc=pl.Checked;engine.Save();Render(true);};
  notifications.CheckedChanged+=(_,_)=>{engine.Data.Notifications=notifications.Checked;engine.Save();};settings.Controls.AddRange([pl,notifications]);
  layout.Controls.Add(tools,0,3);
  search.PlaceholderText="Поиск по названию или описанию…";search.Width=400;search.BackColor=Art.Panel;search.ForeColor=Color.White;search.BorderStyle=BorderStyle.FixedSingle;
  search.TextChanged+=(_,_)=>Render(true);filter.DropDownStyle=ComboBoxStyle.DropDownList;filter.Width=190;filter.Items.AddRange(["Все достижения","Не подтверждено","Подтверждено"]);filter.SelectedIndex=0;filter.SelectedIndexChanged+=(_,_)=>Render(true);
  progress.AutoSize=true;progress.ForeColor=Art.Cyan;progress.Margin=new(18,5,0,0);tools.Controls.AddRange([search,filter]);
  cards.Dock=DockStyle.Fill;cards.AutoScroll=true;cards.FlowDirection=FlowDirection.TopDown;cards.WrapContents=false;cards.Resize+=(_,_)=>{foreach(Control c in cards.Controls)c.Width=Math.Max(700,cards.ClientSize.Width-25);};content.Controls.Add(cards);missions.Visible=false;content.Controls.Add(missions);layout.Controls.Add(content,0,4);
  footer.Dock=DockStyle.Fill;footer.ForeColor=Art.Muted;footer.Font=new("Segoe UI",9);footer.Padding=new(0,8,0,0);layout.Controls.Add(footer,0,5);
  engine.Unlocked+=(a,source)=>{if(!initialScan)QueueToast(a,source);};
  tray=new NotifyIcon{Text="Cyberpunk Tracker",Icon=SystemIcons.Application,Visible=true};
  var menu=new ContextMenuStrip();menu.Items.Add("Открыть",null,(_,_)=>Restore());menu.Items.Add("Выход — остановить учёт",null,(_,_)=>Close());tray.ContextMenuStrip=menu;tray.DoubleClick+=(_,_)=>Restore();
  timer.Tick+=async(_,_)=>await Poll();Shown+=async(_,_)=>{Render(true);await Poll();timer.Start();};
  FormClosing+=(_,e)=>{timer.Stop();try{engine.Dispose();}catch(Exception ex){e.Cancel=true;timer.Start();MessageBox.Show("Не удалось сохранить данные: "+ex.Message);}if(!e.Cancel){toast?.Close();tray.Visible=false;tray.Dispose();}};
 }
 void Restore(){Show();WindowState=FormWindowState.Normal;Activate();}
 void Guard(Action action){try{action();engine.Save();Render(true);}catch(Exception e){MessageBox.Show(this,e.Message,"Операция не выполнена",MessageBoxButtons.OK,MessageBoxIcon.Warning);}}
 void Import(){using var d=new OpenFileDialog{Filter="Сейвы и JSON|*.json;*.dat",Title="Метаданные, sav.dat или журнал достижений",Multiselect=true};if(d.ShowDialog(this)!=DialogResult.OK)return;Guard(()=>{var results=d.FileNames.Select(p=>engine.Import(p)).ToList();MessageBox.Show(this,string.Join("\n",results.Select(r=>r.Message)),"Импорт");});}
 void Baseline(){using var f=new Form{Text="Стартовое время",Size=new(470,220),StartPosition=FormStartPosition.CenterParent,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,BackColor=Art.Bg,ForeColor=Color.White};var label=new Label{Text="Часы до начала учёта. Заменяет базу,\nнакопленные сессии сохраняются.",Location=new(18,15),AutoSize=true};var n=new NumericUpDown{Location=new(18,72),Width=240,DecimalPlaces=6,Maximum=100000,Value=(decimal)(engine.Data.BaselineSeconds/3600)};var b=Art.Button("Сохранить",(_,_)=>{Guard(()=>engine.SetBaseline((double)n.Value));f.DialogResult=DialogResult.OK;});b.Location=new(18,113);f.Controls.AddRange([label,n,b]);f.ShowDialog(this);}
 void Sessions(){var text=engine.Data.Sessions.Count==0?"Сессий ещё нет.":string.Join(Environment.NewLine,engine.Data.Sessions.AsEnumerable().Reverse().Take(100).Select(s=>$"{s.Started.LocalDateTime:g}  —  {Engine.Duration(s.Seconds)}"));ShowText("Последние сессии",text);}
 void ShowText(string title,string text){using var f=new Form{Text=title,Size=new(760,530),StartPosition=FormStartPosition.CenterParent};var t=new TextBox{Multiline=true,ReadOnly=true,Dock=DockStyle.Fill,ScrollBars=ScrollBars.Vertical,Text=text,Font=new("Segoe UI",11),BackColor=Art.Panel,ForeColor=Color.White};f.Controls.Add(t);f.ShowDialog(this);}
 string? PickFolder(string title){using var d=new FolderBrowserDialog{Description=title,UseDescriptionForTitle=true};return d.ShowDialog(this)==DialogResult.OK?d.SelectedPath:null;}
 void SaveFolder(){var p=PickFolder("Папка сохранений Cyberpunk 2077 (только чтение)");if(p!=null)Guard(()=>engine.Data.SaveFolder=p);}
 void GameFolder(){var p=PickFolder("Корень игры — папка, содержащая bin\\x64\\Cyberpunk2077.exe");if(p==null)return;Guard(()=>{
  if(!File.Exists(Path.Combine(p,"bin","x64","Cyberpunk2077.exe")))throw new InvalidDataException("В папке не найден bin\\x64\\Cyberpunk2077.exe");
  engine.Data.GameFolder=p;engine.Data.LogPath=Path.Combine(p,"bin","x64","plugins","cyber_engine_tweaks","mods","local_achievement_bridge","unlocks.jsonl");
 });}
 void LogFile(){using var d=new OpenFileDialog{Filter="Журналы JSON / JSONL|*.json;*.jsonl;*.log|Все файлы|*.*"};if(d.ShowDialog(this)==DialogResult.OK)Guard(()=>engine.Data.LogPath=d.FileName);}
 void CetHelp(){ShowText("Автоматические события CET", "Для уведомлений в момент события требуется мост CET из комплекта.\r\n\r\nЗакройте игру. Скопируйте папку local_achievement_bridge из CET-мост в bin\\x64\\plugins\\cyber_engine_tweaks\\mods. Затем в программе выберите «Папка игры».\r\n\r\nСам трекер открывает файлы игры и сейвы только для чтения. Установка моста выполняется вами отдельно; мост пишет только собственный журнал.\r\n\r\nМост наблюдает вызов UnlockAchievement, не вызывает выдачу ачивок и не изменяет сейв. Совместимость с вашей сборкой требует проверки в игре. Состояние моста видно в нижней строке окна.\r\n\r\nУведомления поверх игры работают в оконном режиме / без рамки; для эксклюзивного полноэкранного режима показа не гарантируем. Программа должна оставаться запущенной (можно в трее).\r\n\r\nСтарые ачивки можно импортировать из реального локального журнала. Штатный CET-лог не обязан содержать историю. Неподтверждённые достижения остаются без отметки.");}
 static void OpenFolder(string p){Directory.CreateDirectory(p);Process.Start(new ProcessStartInfo(p){UseShellExecute=true});}
 async Task Poll(){
  if(busy)return;busy=true;
  try{
   bool running=await Task.Run(()=>{var ps=Process.GetProcessesByName("Cyberpunk2077");try{return ps.Length>0;}finally{foreach(var p in ps)p.Dispose();}});
   engine.Tick(running);total.Text="Время в игре: "+Engine.Duration(engine.TotalSeconds);gameStatus.Text=running?"● Игра запущена • учёт идёт":"○ Игра не запущена";gameStatus.ForeColor=running?Art.Cyan:Art.Muted;
   if(tick++%2==0){var errors=engine.Scan();initialScan=false;engine.Save();Render();if(missionPage)UpdateMissionReport();footer.Text=errors.Count>0?string.Join("  ",errors.Take(2)):BridgeStatus();}
  }catch(Exception e){footer.Text="Ошибка: "+e.Message;}finally{busy=false;}
 }
 string BridgeStatus(){
  string text="Сейвы: только чтение. База: "+Engine.Duration(engine.Data.BaselineSeconds)+". ";
  if(string.IsNullOrEmpty(engine.Data.LogPath))return text+"Журнал не выбран — живые события CET не подключены.";
  var status=Path.Combine(Path.GetDirectoryName(engine.Data.LogPath)!,"bridge-status.json");
  if(File.Exists(status))try{using var d=JsonDocument.Parse(Engine.ReadShared(status));var root=d.RootElement;var mode=root.GetProperty("state").GetString();return text+"CET: "+mode+". Журнал: "+Path.GetFileName(engine.Data.LogPath);}catch{}
  return text+"Журнал выбран. Совместимость CET пока не подтверждена.";
 }
 void Render(bool force=false){
  string sig=$"{search.Text}|{filter.SelectedIndex}|{pl.Checked}|"+string.Join(";",engine.Data.Achievements.OrderBy(k=>k.Key).Select(k=>k.Key+":"+string.Join(',',k.Value.Select(v=>v.Source))))+string.Join(";",engine.Data.Progress.Select(k=>k.Key+":"+k.Value.Current));
  var all=engine.Catalog.Where(a=>pl.Checked||!a.Dlc).ToList();int unlocked=all.Count(a=>engine.Data.Achievements.TryGetValue(a.Id,out var e)&&e.Count>0);progress.Text=$"Разблокировано достижений: {unlocked}/{all.Count} ({(all.Count==0?0:100*unlocked/all.Count)}%) • Только ваш прогресс";progressBar.Value=all.Count==0?0:1000*unlocked/all.Count;
  if(!force&&signature==sig)return;signature=sig;cards.SuspendLayout();
  foreach(Control c in cards.Controls.Cast<Control>().ToArray()){cards.Controls.Remove(c);c.Dispose();}
  var items=all.Where(a=>(a.Label+" "+a.Description+" "+a.Id).Contains(search.Text,StringComparison.OrdinalIgnoreCase)).Where(a=>filter.SelectedIndex==0||(filter.SelectedIndex==2)==(engine.Data.Achievements.TryGetValue(a.Id,out var r)&&r.Count>0));
  foreach(var a in items){
   var records=engine.Data.Achievements.GetValueOrDefault(a.Id)??[];bool earned=records.Count>0;
   var card=new Panel{Width=Math.Max(700,cards.ClientSize.Width-25),Height=130,BackColor=Art.Panel,Margin=new(0,0,0,10),Padding=new(12)};
   var pic=new PictureBox{Image=icons[a.Id],SizeMode=PictureBoxSizeMode.Zoom,Location=new(12,17),Size=new(88,88)};
   var name=new Label{Text=a.Label+(a.Dlc?"  •  PHANTOM LIBERTY":""),Location=new(116,10),AutoSize=false,Size=new(card.Width-340,28),Font=new("Segoe UI",12,FontStyle.Bold),ForeColor=earned?Art.Yellow:Color.White};
   var desc=new Label{Text=a.Description,Location=new(116,42),AutoSize=false,Size=new(card.Width-300,43),ForeColor=Art.Muted,Font=new("Segoe UI",9.5f)};
   var state=new Label{Text=earned?"✓ Подтверждено • "+string.Join(", ",records.Select(e=>e.Source).Distinct()):"○ Не подтверждено"+(engine.Data.Progress.TryGetValue(a.Id,out var observed)?$" • {observed.Current}/{observed.Target} (сейв)":""),Location=new(116,91),AutoSize=false,Size=new(card.Width-300,25),ForeColor=earned?Art.Cyan:Art.Muted,Font=new("Segoe UI",9)};
   var button=Art.Button(records.Any(r=>r.Source=="вручную")?"Снять ручную":"Отметить",(_,_)=>Guard(()=>{if(records.Any(r=>r.Source=="вручную"))engine.RemoveManual(a.Id);else engine.Confirm(a.Id,"вручную","Отметка пользователя",true);}));button.Location=new(card.Width-153,13);button.Width=135;button.Anchor=AnchorStyles.Right|AnchorStyles.Top;
   var info=Art.Button("Источник",(_,_)=>ShowText(a.Label,a.Description+"\r\n\r\nОтслеживание: "+a.Tracking+"\r\n\r\nID: "+a.Id+"\r\n\r\n"+(records.Count==0?"Данных о выполнении нет.":string.Join("\r\n\r\n",records.Select(r=>$"{r.Source} • {r.At.LocalDateTime:g}\r\n{r.Detail}")))));info.Location=new(card.Width-153,65);info.Width=135;info.Anchor=AnchorStyles.Right|AnchorStyles.Top;
   card.Controls.AddRange([pic,name,desc,state,button,info]);card.Resize+=(_,_)=>{name.Width=card.Width-290;desc.Width=card.Width-290;state.Width=card.Width-290;};cards.Controls.Add(card);
  }
  if(cards.Controls.Count==0)cards.Controls.Add(new Label{Text="Достижения не найдены. Измените поиск или фильтр.",AutoSize=true,ForeColor=Art.Muted});
  cards.ResumeLayout();if(missionPage)RenderMissions();
 }

 string MissionReportPath=>Path.Combine(engine.Data.GameFolder,"bin","x64","plugins","cyber_engine_tweaks","mods","local_achievement_bridge","missions-report.json");
 string reportSignature="";
 void RenderMissions(){
  missions.SuspendLayout();foreach(Control c in missions.Controls.Cast<Control>().ToArray()){missions.Controls.Remove(c);c.Dispose();}
  var note=new Label{Text="Разблокировка миссий — отдельный раздел. Сейвы остаются только для чтения.\nСчётчик не заменяет завершение задания: пока команды изменения прогресса не проверены, они отключены.",ForeColor=Art.Muted,Size=new(Math.Max(700,content.Width-30),56)};missions.Controls.Add(note);
  var inspect=Art.Button("Проверить миссии через CET",(_,_)=>Guard(RequestMissionInspection));missions.Controls.Add(inspect);
  var show=Art.Button("Открыть отчёт CET",(_,_)=>Guard(()=>{if(!File.Exists(MissionReportPath))throw new InvalidOperationException("Отчёт ещё не получен. Подключите обновлённый CET-мост и запустите игру.");ShowText("Диагностика миссий",Engine.ReadShared(MissionReportPath));}));missions.Controls.Add(show);
  var profiles=new[]{("tarot","Шут из Найт-Сити","Граффити с арканами таро", "Fortuneteller",20),("minor","Вот скажи мне","Младшие арканы; в вашей игре цель 12", "mission_minor",12),("psychos","Анатомия убийства","17 отдельных киберпсихопатов, отчёты и награда", "mission_psychos",17),("delamain","Реинтеграция","Машины Деламейна и переход к следующему этапу", "mission_delamain",7)};
  foreach(var (id,title,description,key,target) in profiles){
   var panel=new Panel{Width=Math.Max(700,content.Width-30),Height=130,BackColor=Art.Panel,Margin=new(0,4,0,8)};
   var observed=engine.Data.Progress.GetValueOrDefault(key);
   panel.Controls.Add(new Label{Text=title,Font=new("Segoe UI",12,FontStyle.Bold),Location=new(14,10),Size=new(panel.Width-250,26)});
   panel.Controls.Add(new Label{Text=description+"\nПрогресс по сейву: "+(observed==null?"не определён":$"{observed.Current}/{target}"),ForeColor=Art.Muted,Location=new(14,42),Size=new(panel.Width-250,45)});
   var button=Art.Button("Разблокировать",(_,_)=>{});button.Enabled=false;button.Location=new(panel.Width-180,15);panel.Controls.Add(button);
   panel.Controls.Add(new Label{Text="Недоступно: правильная последовательность завершения и награда ещё не проверены.",ForeColor=Art.Yellow,Location=new(14,94),Size=new(panel.Width-20,25),Font=new("Segoe UI",9)});
   missions.Controls.Add(panel);
  }
  missions.ResumeLayout();
 }
 void RequestMissionInspection(){
  if(string.IsNullOrWhiteSpace(engine.Data.GameFolder)||string.IsNullOrWhiteSpace(engine.Data.LogPath))throw new InvalidOperationException("Сначала выберите «Папка игры» и установите обновлённый CET-мост из архива.");
  var dir=Path.Combine(engine.Data.GameFolder,"bin","x64","plugins","cyber_engine_tweaks","mods","local_achievement_bridge");
  if(!File.Exists(Path.Combine(dir,"missions.lua")))throw new InvalidOperationException("Обновлённый CET-мост не найден. Скопируйте его из новой сборки при закрытой игре.");
  var request=new{version=1,action="inspect_missions",id=Guid.NewGuid().ToString(),expires=DateTimeOffset.UtcNow.AddSeconds(60).ToUnixTimeSeconds()};
  var temp=Path.Combine(dir,"mission-request.tmp");File.WriteAllText(temp,JsonSerializer.Serialize(request));File.Move(temp,Path.Combine(dir,"mission-request.json"),true);
  footer.Text="Запрос диагностики отправлен. Он только читает прогресс; ожидаю CET в запущенной игре.";
 }
 void UpdateMissionReport(){
  if(!File.Exists(MissionReportPath))return;
  var f=new FileInfo(MissionReportPath);var sig=f.LastWriteTimeUtc.Ticks.ToString();if(sig==reportSignature)return;
  reportSignature=sig;using var doc=JsonDocument.Parse(Engine.ReadShared(MissionReportPath));
  if(doc.RootElement.TryGetProperty("error",out var error))footer.Text="Диагностика CET: "+error.GetString();
 }
 void QueueToast(Achievement a,string source){toasts.Enqueue((a,source));NextToast();}
 void NextToast(){if(toast!=null||toasts.Count==0)return;var item=toasts.Dequeue();toast=new Toast(item.Item1,icons[item.Item1.Id],item.Item2);toast.FormClosed+=(_,_)=>{toast=null;NextToast();};toast.Show();}
 protected override void Dispose(bool disposing){if(disposing){timer.Dispose();foreach(var i in icons.Values)i.Dispose();}base.Dispose(disposing);}
}
public sealed class Toast : Form {
 readonly System.Windows.Forms.Timer life=new(){Interval=6500};
 protected override bool ShowWithoutActivation=>true;
 protected override CreateParams CreateParams {get{var c=base.CreateParams;c.ExStyle|=0x08000000|0x80;return c;}}
 [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int cx,int cy,uint flags);
 public Toast(Achievement a,Image icon,string source){
  FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;TopMost=true;StartPosition=FormStartPosition.Manual;Size=new(460,142);BackColor=Art.Panel;ForeColor=Color.White;
  var bounds=(Screen.PrimaryScreen??Screen.FromPoint(Cursor.Position)).WorkingArea;Location=new(bounds.Right-Width-22,bounds.Top+22);
  var stripe=new Panel{Dock=DockStyle.Left,Width=5,BackColor=Art.Cyan};var image=new PictureBox{Image=icon,SizeMode=PictureBoxSizeMode.Zoom,Location=new(17,26),Size=new(76,76)};
  var heading=new Label{Text=source.StartsWith("Проверка")?"ПРОВЕРКА УВЕДОМЛЕНИЯ":"ДОСТИЖЕНИЕ ПОДТВЕРЖДЕНО",Location=new(108,12),AutoSize=true,ForeColor=Art.Cyan,Font=new("Segoe UI",9,FontStyle.Bold)};
  var title=new Label{Text=a.Label,Location=new(108,36),Size=new(330,28),Font=new("Segoe UI",12,FontStyle.Bold)};
  var description=new Label{Text=a.Description,Location=new(108,66),Size=new(330,40),Font=new("Segoe UI",9)};
  var label=new Label{Text="Источник: "+source,Location=new(108,113),Size=new(330,20),ForeColor=Art.Muted,Font=new("Segoe UI",8)};
  Controls.AddRange([stripe,image,heading,title,description,label]);life.Tick+=(_,_)=>Close();Shown+=(_,_)=>{SetWindowPos(Handle,new IntPtr(-1),Left,Top,Width,Height,0x10|0x40);life.Start();};Click+=(_,_)=>Close();
 }
 protected override void Dispose(bool disposing){if(disposing)life.Dispose();base.Dispose(disposing);}
}
