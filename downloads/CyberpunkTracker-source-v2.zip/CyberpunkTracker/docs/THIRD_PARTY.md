# Источники

Факты каталога (API ID, английское название/описание и URL изображений):
https://github.com/DYH1319/steam-stat-public-data
коммит data: 5bb41c9d34e638e6e6bb6a3a7a6e14005bdf23c4,
achievements/ac.616a393d2fb9d00d.json, app 1091500.
Названия игр и достижения принадлежат их правообладателям. Картинки Steam
не скачаны и не включены; PNG в assets — собственные иллюстрации.
Русский текст — редакционный перевод и описание скрытых условий.

Справка по CET проверена по открытому коду:
https://github.com/maximegmd/CyberEngineTweaks
src/scripting/Scripting.cpp, FunctionOverride.cpp, LuaSandbox.cpp,
src/reverse/Enum.cpp. Код CET в приложение не скопирован и не включён.
CET и сама игра не входят в комплект.

Самостоятельный EXE включает Microsoft .NET 8 Windows Desktop Runtime.
Файлы LICENSE.NET.txt и THIRD_PARTY_NOTICES.NET.txt сопровождают дистрибутив.
